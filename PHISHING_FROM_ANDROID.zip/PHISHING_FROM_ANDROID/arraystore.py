import numpy as np

def mainp(newar):
  if(newar[1]==0 or newar[5]==-1 or newar[6]==-1 or newar[6]==0 or newar[2]==-1 or newar[4]==-1 or newar[9]==-1 or newar[21]==-1) :
        return int(-1)
  else:
        return int(1)

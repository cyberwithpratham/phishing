from flask import Flask, render_template, request, redirect, url_for, flash
from flask.globals import session
import pickle , re, os
import pandas as pd
import numpy as np
import sklearn as sk
import pickle
import socket as s
from csv import reader
import json
datetimeFormat = '%Y-%m-%d %H:%M:%S.%f'
  #id, subject, staff, date_, students
import datetime as dt
from datetime import timedelta
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB, GaussianNB
from sklearn.model_selection import train_test_split

app = Flask(__name__,template_folder='template')
app.secret_key = '1F4453C6EA2C5B454D221285FFFFC'

import features_extraction
import sys
import numpy as np
import arraystore
#from features_extraction import LOCALHOST_PATH, DIRECTORY_NAME
import joblib
from urllib.parse import urlparse
import sklearn
print(sklearn.__version__)
import warnings
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=DeprecationWarning)
def get_prediction_from_url(test_url):
    features_test = features_extraction.main(test_url)
    features_test = np.array(features_test).reshape((1, -1))
    newar=features_test[0]
    i= int(arraystore.mainp(newar))
    
    clf = joblib.load('classifier/rf.pkl')
    #print(type(features_test))
    pred = clf.predict(features_test)
    domain = urlparse(test_url).netloc
    
    if(i==-1) :
        return int(-1)
    else:
        return int(1)


@app.route('/analysis',methods=["POST","GET"])
def analysis():
    url = request.form['url']
    prediction = get_prediction_from_url(url)

    if prediction == 1:
        print("\n")
        print ("\n The website is safe to browse")
        print(" ")
        #print("SAFE")
        x={"success":"This website is safe to browse. Go ahead.."}
            #return render_template('index.html', value=output)
        return json.dumps(x)
         
    elif prediction == -1:
        print("phishing")
        x= {"success":"The website has phishing features. DO NOT VISIT!"}
       
        return json.dumps(x)
    
        
if __name__ == '__main__':  
    app.run(debug=True,host='0.0.0.0')
